# OSCLeash plugin for OSC-DreamChatbox

Runs [OSCLeash](https://github.com/ZenithVal/OSCLeash) by ZenithVal as a
child process of the chatbox – one process per leash, each with its own
generated `Config.json`, its own Start/Stop button and its own console.

OSCLeash itself is **not** bundled and **not** modified. It stays MIT
licensed and is installed separately (AUR `OSCLeash`, the AppImage from
the releases page, or a source checkout).

## The panel

* **Start all / Stop all** – everything at once.
* **✚ Add leash** – one more instance. Needed whenever a second leash has
  its own compass: OSCLeash's `DirectionalParameters` are a single set
  per config, so a tail with its own contacts cannot share the config of
  the collar.
* **▶ / ■** per row – start or stop exactly this instance.
* **🐞 Debug** – the raw output of exactly this process, in its own
  window. Colour codes are stripped, repeated lines are collapsed into
  `(xN)`, and the plugin's own notes are marked with `»`.
* **⚙** – the settings of this leash: physbone parameters, contact
  prefix, ports, deadzones, strength, turning, delays.
* **🗑** – remove the leash and its generated config.

Instance settings are read when the instance **starts**. Changing
something while it runs shows a reminder to stop and start it again.

## Ports and OSCQuery

VRChat sends avatar data to port 9001 exactly once. A second instance on
the same machine therefore only receives anything with **OSCQuery**
switched on, which is why every leash added after the first gets it
enabled automatically. The panel warns when two running instances
without OSCQuery listen on the same port.

## Placeholders

| Placeholder | Meaning |
| --- | --- |
| `{oscleash}` | ready-made line, e.g. `🐕 Leash ↗` |
| `{oscleash_state}` | `pulled`, or `ready` while idle |
| `{oscleash_dir}` | ↑ ↗ → ↘ ↓ ↙ ← ↖ |
| `{oscleash_compass}` | `N` `NE` `E` … |
| `{oscleash_name}` | the leash currently being pulled |
| `{oscleash_count}` | running instances |

Direction and strength are read from OSCLeash's log output, so the
instance needs **Debug output** switched on (it is, by default). Without
it the plugin still knows *that* a leash is being pulled, just not where
to. Nothing here opens a second OSC port – a second listener would take
data away from OSCLeash itself.

## Where things are stored

```
plugins/oscleash/configs/instances.json          the leash list
plugins/oscleash/configs/instances/<id>/Config.json   generated per start
```

`OSCLEASH_CONFIG_PATH` points each process at its own file, so the
plugin never touches `~/.config/OSCLeash/Config.json`.

## Optional: the panel inside the Plugins page

The plugin exposes `build_widget(parent)`. A host that calls it embeds
the panel directly under the plugin's settings; a host that does not is
fully supported too – the **🎛 Control panel** toggle opens the same
panel in its own window.
