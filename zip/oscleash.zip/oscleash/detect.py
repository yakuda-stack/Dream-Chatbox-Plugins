"""Finding the OSCLeash executable.

OSCLeash ships in five shapes and the plugin has to cope with all of
them, because none of them is "the" Linux install:

    AUR            /usr/bin/OSCLeash            (also -nuitka)
    AppImage       ~/Applications/OSCLeash.appimage
    PyInstaller    a plain ELF binary somewhere the user dropped it
    Source         OSCLeash.py next to Controllers/
    Windows        %LocalAppData%\\Programs\\OSCLeash\\OSCLeash.exe

The user can always override the result with the "OSCLeash path"
setting; autodetect only fills in the blank.
"""

# Copyright (C) 2026 yakuda
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import shutil
import sys
from pathlib import Path

IS_WINDOWS = os.name == "nt"

# tried in this order, so a proper install wins over a stray download
WHICH_NAMES = ("OSCLeash", "oscleash", "OSCLeash-nuitka", "OSCLeash-Nuitka",
               "OSCLeash-pyinstaller")

FILE_NAMES = ("OSCLeash", "OSCLeash.appimage", "OSCLeash.AppImage",
              "OSCLeash-x86_64.AppImage", "OSCLeash-Nuitka",
              "OSCLeash-pyinstaller", "OSCLeash.exe", "OSCLeash.py")


def _search_dirs():
    home = Path.home()
    dirs = [home / ".local/bin", home / "bin", home / "Applications",
            home / "AppImages", home / "Apps", home / "Downloads",
            Path("/opt/OSCLeash"), Path("/usr/lib/OSCLeash"),
            Path("/usr/share/OSCLeash")]
    if IS_WINDOWS:
        local = os.environ.get("LocalAppData", "")
        if local:
            dirs.insert(0, Path(local) / "Programs" / "OSCLeash")
    # a source checkout, wherever people usually keep one
    for parent in (home, home / "git", home / "Git", home / "Projects",
                   home / "Documents"):
        dirs.append(parent / "OSCLeash")
    return dirs


def find_binary():
    """Best guess at an OSCLeash executable, or "" when there is none."""
    for name in WHICH_NAMES:
        hit = shutil.which(name)
        if hit:
            return hit
    for folder in _search_dirs():
        try:
            if not folder.is_dir():
                continue
        except OSError:          # unreadable mount, permission denied
            continue
        for name in FILE_NAMES:
            candidate = folder / name
            if candidate.is_file():
                return str(candidate)
    return ""


def kind_of(path):
    """binary | appimage | source – decides how the process is started."""
    name = Path(path).name.lower()
    if name.endswith(".py"):
        return "source"
    if "appimage" in name:
        return "appimage"
    return "binary"


def build_command(path):
    """The argv list for one instance, or None when the path is unusable.

    A source checkout is run with the interpreter the chatbox itself is
    using only as a last resort: OSCLeash needs python-osc, and the app's
    venv usually has it because the chatbox speaks OSC too.
    """
    path = str(path or "").strip()
    if not path:
        return None
    p = Path(path).expanduser()
    if not p.is_file():
        return None
    kind = kind_of(p)
    if kind == "source":
        return [sys.executable, str(p)]
    return [str(p)]


def workdir_for(path):
    """OSCLeash's source build imports Controllers/ relative to the file,
    so the working directory has to be the checkout, not the chatbox."""
    return str(Path(path).expanduser().parent)


def is_executable(path):
    p = Path(str(path)).expanduser()
    if not p.is_file():
        return False
    if kind_of(p) == "source" or IS_WINDOWS:
        return True
    return os.access(str(p), os.X_OK)
