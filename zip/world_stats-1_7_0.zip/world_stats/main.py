"""World Stats – live VRChat instance info, session timers, battery, FPS.

Things that all want to sit in the same chatbox line, and none of which
the chatbox itself should have to know about:

  world      {player_in_world} {group_world} {instance_type}
             {vrc_region} {vrc_instance_capacity} {vrc_master}
             parsed out of VRChat's output_log by vrchatlog.py, which
             ships next to this file – uninstall the plugin and the log
             reading and its thread are gone with it. The capacity is
             the one value the log does not have: capacity.py asks
             VRChat's public world endpoint for it, once per world.

  session    {world_time} {vr_time}
             how long you have been in this instance and how long
             VRChat has been running. Both come out of the log's own
             timestamps, not from a stopwatch started here, so they
             survive restarting the chatbox mid-session.

  clock      MOVED to the Life Stats plugin in v1.7.0 – it never had
             anything to do with VRChat. The placeholder names stayed
             the same ({realtime} {realdate} {realday} {realtime_alt}),
             and Life Stats takes the clock settings over from here.

  battery    {hmd_battery} {controller_battery} {tracker_battery}
             {tracker_lowest_name}
             from battery.py, over adb for a standalone headset or over
             SteamVR/OpenVR for everything else. Also independent – it
             does not care where you are or whether you are in VR at all.

All of these are declared as global_placeholders in plugin.json, so the
plain names work everywhere: status texts, Apps custom strings, AIO.
"""

# Copyright (C) 2026 yakuda
# SPDX-License-Identifier: GPL-3.0-or-later

import threading
import time

_api = None
_watcher = None
_battery = None
_fps = None
_capacity = None
_warned = False
_app_start = 0.0     # only used by the "since the app started" source

# Read-only rows in the settings block are written from _sync_status(),
# which only ever runs on the GUI thread. A worker that wants to say
# something leaves it in _notes instead of calling api.set() itself -
# touching a widget from a worker thread is a segfault, not an
# exception. _written caches what is already there so the same string
# is not pushed back into the config once a frame.
_notes = {}          # key -> (text, valid_until)

# How long the Read-now button may hold the GUI thread while it waits
# for the poll it just asked for. Only ever spent on an explicit click,
# never on the timed polls.
ACTION_WAIT = 1.2
_written = {}
_last_write = {}     # key -> monotonic time of the last api.set()

#: Floor between two writes of the same settings key. api.set() persists
#: to config.json, so a row whose text moves on its own is a disk write
#: every time it moves. v1.5.0 had exactly that: the FPS status row
#: carried the live frame rate, which changes on nearly every read, and
#: _sync_status() runs once a chatbox frame - about six config writes a
#: second for as long as FPS was switched on. Unnoticeable on an SSD;
#: enough to make the whole app look frozen on a failing drive, because
#: every one of those writes waits on the disk.
#:
#: The volatile number is gone (see fps.status_line), and this is the
#: belt to that pair of braces: no status row this plugin ever grows can
#: bring the behaviour back.
#:
#: Deferred, not dropped. _sync_status() recomputes and re-offers every
#: row on every frame, so a value held back here is written by the first
#: call after the floor passes. Notes bypass it entirely - a message
#: that expires before it is shown was pointless to write.
MIN_WRITE_SEC = 2.0


# ---------------------------------------------------------------- setup
def setup(api):
    global _api, _watcher, _battery, _fps, _app_start
    _api = api
    _app_start = time.time()

    if not _supports("api.set"):
        # not fatal, and deliberately not an exception: everything the
        # plugin actually produces works without it. Only the read-only
        # Status rows stay on their default text.
        _log("this app build has no api.set() – the plugin runs, but the "
             "Status rows stay empty. App v1.3.2 or newer fills them in.")

    try:
        from .vrchatlog import VRChatLogWatcher
    except Exception as e:
        _log(f"vrchatlog.py not importable ({e}) – "
             f"clock and battery still work.")
    else:
        _watcher = VRChatLogWatcher(_log)
        _apply_log_dir()
        if _needs_log():
            _watcher.start()
            _log("watching the VRChat log for players/world")

    try:
        from .battery import BatteryMonitor
    except Exception as e:
        _log(f"battery.py not importable ({e}) – "
             f"battery placeholders stay empty.")
    else:
        _battery = BatteryMonitor(_log)
        _apply_battery()

    try:
        from .fps import FpsMonitor
    except Exception as e:
        _log(f"fps.py not importable ({e}) - the FPS placeholders stay empty.")
    else:
        _fps = FpsMonitor(_log)
        _apply_fps()

    try:
        from .battery import openvr_available
        _note("openvr_status", openvr_available()[1], 10 ** 6)
    except Exception:
        pass
    try:
        from .battery import monado_available
        _note("monado_status", monado_available()[1], 10 ** 6)
    except Exception:
        pass
    _announce_move()
    _sync_status()


def _announce_move():
    """The clock left for Life Stats. Say so once in the log - the
    settings block says it at the top as well."""
    if _get("clock", False) or any(_get(k) for k in ("clock_date",
                                                    "clock_alt")):
        _log("the clock moved to the Life Stats plugin (World Stats "
             "v1.7.0) - install Life Stats from the store; your clock "
             "settings are taken over.")


def teardown():
    global _watcher, _battery, _fps
    for obj in (_watcher, _battery):
        try:
            if obj is not None:
                obj.stop()
        except Exception:
            pass
    _watcher = None
    _battery = None
    # nothing to stop: the FPS monitor holds no thread and no process,
    # only a cached number. The Vulkan layer manifest is deliberately
    # NOT removed here - teardown() also runs on app shutdown, and
    # deleting it every time the app closes would mean the next game
    # launched before the chatbox is not measured.
    _fps = None
    _notes.clear()
    _written.clear()
    _last_write.clear()
    _invalidate_values()


def on_event(name, data=None):
    if name == "app.shutdown":
        teardown()


# ------------------------------------------------------------- settings
def on_settings(settings):
    """The user changed something in the Settings block."""
    # a toggle has to show up on the very next frame, not once the
    # memoised pass has aged out
    _invalidate_values()
    if _watcher is not None:
        _apply_log_dir()
        if _needs_log():
            _watcher.start()
        else:
            _watcher.stop()
    _apply_battery()
    _apply_fps()
    _sync_status()


def _supports(feature):
    """Does the host offer this optional API feature?

    api.supports() is itself a Plugin API v2 addition, so asking with it
    directly is exactly the thing that must not be done: on an older app
    the whole plugin died in setup() with

        AttributeError: 'PluginAPI' object has no attribute 'supports'

    which is a hard load failure for a feature that is optional by
    definition. So: use supports() when it is there, and otherwise look
    for the method the feature is named after - "api.set" -> is there a
    callable api.set? An old host without api.set then simply loses the
    read-only status rows instead of the entire plugin."""
    if _api is None:
        return False
    probe = getattr(_api, "supports", None)
    if callable(probe):
        try:
            return bool(probe(feature))
        except Exception:
            pass
    return callable(getattr(_api, feature.rsplit(".", 1)[-1], None))


def _log(msg):
    """api.log if the host has one, stdout if it does not."""
    fn = getattr(_api, "log", None) if _api is not None else None
    if callable(fn):
        try:
            fn(msg)
            return
        except Exception:
            pass
    print(f"[world_stats] {msg}")


def _get(key, default=None):
    if _api is None:
        return default
    try:
        return _api.get(key, default)
    except Exception:
        return default


def _set(key, value, urgent=False):
    """Write a settings row, but only when it really changed - and not
    more often than MIN_WRITE_SEC, because api.set() goes to disk.

    on_settings() fires on every write, and on_settings() calls back
    into here - without the change guard that is a loop.

    ``urgent`` skips the rate limit. Used for the _note() messages,
    which carry their own expiry and would be worthless if they landed
    after it.
    """
    if _written.get(key) == value:
        return
    if not urgent:
        now = time.monotonic()
        if now - _last_write.get(key, -1e9) < MIN_WRITE_SEC:
            return          # the next frame offers this row again
    _written[key] = value
    _last_write[key] = time.monotonic()
    if _supports("api.set"):
        try:
            _api.set(key, value)
        except Exception:
            pass


def _note(key, text, secs=15.0):
    """Leave a message for the next _sync_status(). Thread safe: a dict
    assignment is all that happens here."""
    _notes[key] = (text, time.time() + secs)


def _apply_log_dir():
    folder = str(_get("log_dir", "")).strip()
    try:
        _watcher.set_override(folder)
    except Exception as e:
        _log(f"could not set the log folder: {e}")


def _needs_log():
    """Anything that has to read the log file.

    The world timer always needs it. The VR timer only needs it while
    it is set to the VRChat session - on "since the app started" it is
    a plain subtraction and the watcher can stay off."""
    if _get("players", True) or _get("world", True):
        return True
    if _get("region", False) or _get("capacity", False) \
            or _get("master", False):
        return True
    if _get("world_time", False):
        return True
    return bool(_get("vr_time", False)
                and str(_get("vr_time_source", "vrchat")) == "vrchat")


def _apply_battery():
    """Push the current settings into the monitor and start or stop it.

    Stopping matters: a switched-off battery block must not keep an adb
    subprocess or an OpenVR session alive in the background."""
    if _battery is None:
        return
    if not _get("battery", False):
        _battery.stop()
        return
    _battery.set_config(
        source=str(_get("battery_source", "auto")),
        interval=int(_get("battery_interval", 60) or 60),
        adb_path=str(_get("adb_path", "")),
        adb_serial=str(_get("adb_serial", "")),
        controllers=bool(_get("battery_controllers", True)),
    )
    _battery.start()


def _apply_fps():
    """Push the settings into the monitor and arm or disarm the layer.

    The checkbox is the switch, exactly as it reads: ticking FPS writes
    the Vulkan layer manifest, unticking it deletes the file again. One
    place does it, so what is on disk cannot disagree with what the UI
    says.
    """
    if _fps is None:
        return
    _fps.set_config(
        source=str(_get("fps_source", "auto")),
        process=str(_get("fps_process", "vrchat")),
        mangohud_dir=str(_get("fps_mangohud_dir", "")),
    )
    _sync_fps_layer()


def _sync_fps_layer():
    """Install or remove the layer manifest to match the settings.

    Idempotent: installing over an existing manifest rewrites it, which
    is also how a library path that moved - a plugin update, an AppImage
    upgrade - gets repaired.
    """
    try:
        from . import fpslayer
    except Exception:
        return
    if fpslayer.IS_WINDOWS:
        return
    wanted = (bool(_get("fps", False))
              and str(_get("fps_source", "auto")) in ("auto", "layer")
              and fpslayer.find_library() is not None)
    try:
        if wanted and not fpslayer.installed():
            ok, msg = fpslayer.install()
            _log(("FPS: " if ok else "FPS: ") + msg)
        elif not wanted and fpslayer.installed():
            ok, msg = fpslayer.uninstall()
            _log("FPS: " + msg)
    except Exception as e:
        _log(f"FPS: layer setup failed ({type(e).__name__}: {e})")


def _fps_status():
    """The read-only Status row under the FPS checkbox."""
    if _fps is None:
        return "fps.py is not loaded"
    if not _get("fps", False):
        return "off"
    try:
        return _clip(_fps.status_line(), 110)
    except Exception as e:
        return f"unavailable ({type(e).__name__})"


def _build_layer_later():
    """gcc takes about a second - too long for the GUI thread."""
    try:
        from . import fpslayer
        ok, msg = fpslayer.build()
    except Exception as e:
        ok, msg = False, f"build failed: {e}"
    _log(f"FPS: {msg}")
    _note("fps_status", _clip(msg, 110), 30.0)
    if ok:
        # a freshly built library still has to be pointed at
        _sync_fps_layer()


def _battery_summary(snap=None):
    """What the Read-now button answers with: the charge itself, not a
    pointer to somewhere else on the page.

    Deliberately not the same string as the Status row - that one names
    the backend and the headset, this one is the number the button was
    pressed for."""
    if _battery is None:
        return ""
    if snap is None:
        snap = _battery.snapshot()
    if not snap:
        return "Battery: starting …"
    if not snap.get("ok"):
        return _clip(snap.get("error") or "no battery source", 70)

    bits = []
    hmd = snap.get("hmd")
    if hmd:
        icon = str(_get("battery_charge_icon", "⚡") if hmd.get("charging")
                   else _get("battery_icon", "🔋")).strip()
        bits.append(f"{icon} {hmd['pct']}%".strip())
        if hmd.get("charging"):
            bits[-1] += " charging"
    ctl = snap.get("controllers") or []
    if ctl:
        bits.append(" ".join(f"{c.get('role') or ''}{c['pct']}%"
                             for c in ctl))
    trk = snap.get("trackers") or []
    if trk:
        low = min(t["pct"] for t in trk)
        bits.append(f"tracker {low}%")
    if not bits:
        return "Battery: nothing reported a charge"
    return "Battery: " + " · ".join(bits)


def _clip(text, limit):
    text = str(text).replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit - 1].rstrip() + "…"


def _sync_status():
    """Rewrite the read-only rows. GUI thread only – called from
    on_settings(), from setup() and once per chatbox frame."""
    for key in ("battery_status", "openvr_status",
                "monado_status", "fps_status"):
        note = _notes.get(key)
        if note and time.time() < note[1]:
            _set(key, note[0], urgent=True)
        elif key == "fps_status":
            _notes.pop(key, None)
            _set(key, _fps_status())
        elif key == "battery_status":
            _notes.pop(key, None)
            if _battery is None or not _get("battery", False):
                _set(key, "off")
            else:
                _set(key, _status_line())

    # Second half of the Read-now answer. The button returns what it
    # knows at the moment of the click; an adb read over WiFi can land
    # after that, and this is what puts the number next to the button
    # anyway. Harmless where the host does not render text on an action
    # row - _set() only writes on change, so it is one no-op write.
    if _battery is not None and _get("battery", False):
        snap = _battery.snapshot()
        if snap.get("seq", 0):
            _set("battery_detect", _battery_summary(snap))


def _status_line():
    snap = _battery.snapshot() if _battery is not None else {}
    if not snap:
        return "starting …"
    if not snap.get("ok"):
        if not snap.get("at"):
            return "looking for a headset …"
        return snap.get("error") or "no battery source"
    bits = [snap.get("source", ""), snap.get("device", "")]
    hmd = snap.get("hmd")
    if hmd:
        bits.append(f"{hmd['pct']}%" + (" charging" if hmd.get("charging")
                                        else ""))
    extra = len(snap.get("controllers") or []) + len(snap.get("trackers")
                                                     or [])
    if extra:
        bits.append(f"+{extra} device{'s' if extra != 1 else ''}")
    return " · ".join(b for b in bits if b)


# -------------------------------------------------------------- buttons
def on_action(key):
    if key == "battery_detect":
        if _battery is None:
            return "battery.py is not loaded"
        if not _get("battery", False):
            return "switch the battery block on first"
        _apply_battery()

        # Wait for this particular poll rather than for "a" poll: the
        # sequence number changes exactly once per completed pass, so a
        # stale reading from a minute ago cannot be mistaken for the
        # answer to this click.
        before = _battery.snapshot().get("seq", 0)
        _battery.poll_now()

        deadline = time.time() + ACTION_WAIT
        snap = _battery.snapshot()
        while time.time() < deadline and snap.get("seq", 0) == before:
            # This is the GUI thread, so the bound matters more than the
            # resolution. Everything but adb answers in well under a
            # tenth of a second; adb over WiFi is the one that can run
            # out the clock, and then the row fills itself in later
            # through _sync_status().
            time.sleep(0.03)
            snap = _battery.snapshot()

        _note("battery_status", _status_line(), 15.0)
        _sync_status()
        if snap.get("seq", 0) == before:
            return "reading …"
        return _battery_summary(snap)

    if key == "fps_build":
        try:
            from . import fpslayer
        except Exception as e:
            return f"fpslayer.py is not loaded ({e})"
        if fpslayer.IS_WINDOWS:
            return "Windows reads RTSS - there is nothing to build."
        ok, why = fpslayer.build_tools()
        if not ok:
            return _clip(f"Cannot build: {why}", 110)
        threading.Thread(target=_build_layer_later, daemon=True).start()
        return "building - this takes a moment"

    if key == "fps_check":
        if _fps is None:
            return "fps.py is not loaded"
        if not _get("fps", False):
            return "switch FPS on first"
        _apply_fps()
        line = _fps.status_line()
        _note("fps_status", _clip(line, 110), 20.0)
        _sync_status()
        return _clip(line, 110)

    if key == "fps_detect_mangohud":
        try:
            from . import fpsmangohud
        except Exception as e:
            return f"fpsmangohud.py is not loaded ({e})"
        folder = fpsmangohud.detect()
        if folder is None:
            return _clip(fpsmangohud.status_line(""), 110)
        _set("fps_mangohud_dir", str(folder))
        _apply_fps()
        return f"found {folder}"

    if key == "adb_connect_now":
        target = str(_get("adb_connect", "")).strip()
        if not target:
            return "put an address like 192.168.1.42 above first"
        threading.Thread(target=_connect_later, args=(target,),
                         daemon=True).start()
        return "connecting …"

    if key == "battery_install_openvr":
        threading.Thread(target=_install_later, daemon=True).start()
        return "installing – this takes a moment"

    return ""


def _connect_later(target):
    """adb blocks for seconds, so it runs here – and reports back
    through _notes rather than touching the settings itself."""
    adb_path = str(_get("adb_path", ""))
    try:
        from .battery import adb_connect, find_adb
        answer = adb_connect(find_adb(adb_path), target)
    except Exception as e:
        answer = f"failed: {e}"
    _log(f"adb connect: {answer}")
    _note("battery_status", answer, 20.0)
    if _battery is not None:
        _battery.poll_now()


def _install_later():
    try:
        from .battery import install_openvr
        answer = install_openvr(_log)
    except Exception as e:
        answer = f"install failed: {e}"
    _note("openvr_status", answer, 10 ** 6)


# -------------------------------------------------------------- battery
_BAR_FULL = "\u25b0"
_BAR_EMPTY = "\u25b1"


def _bar(pct, blocks=5):
    filled = int(round(pct / 100.0 * blocks))
    return _BAR_FULL * filled + _BAR_EMPTY * (blocks - filled)


def _battery_values(vals):
    if _battery is None or not _get("battery", False):
        return
    snap = _battery.snapshot()
    if not snap.get("ok"):
        return

    icon = str(_get("battery_icon", "") or "").strip()
    charge_icon = str(_get("battery_charge_icon", "") or "").strip()
    limit = int(_get("battery_show_below", 100) or 100)

    hmd = snap.get("hmd")
    if hmd and hmd.get("pct") is not None and hmd["pct"] <= limit:
        pct = hmd["pct"]
        shown = charge_icon if (hmd.get("charging") and charge_icon) else icon
        vals["hmd_battery"] = f"{shown} {pct}%".strip()
        vals["hmd_battery_raw"] = str(pct)
        vals["hmd_battery_icon"] = shown or None
        vals["hmd_battery_bar"] = _bar(pct)

    if not _get("battery_controllers", True):
        return

    ctl = [c for c in snap.get("controllers") or []
           if c.get("pct") is not None]
    if ctl:
        cicon = str(_get("controller_icon", "") or "").strip()
        parts = []
        for c in ctl:
            role = c.get("role") or ""
            mark = charge_icon if (c.get("charging") and charge_icon) else ""
            parts.append(f"{role}{c['pct']}%{mark}".strip())
        if min(c["pct"] for c in ctl) <= limit:
            vals["controller_battery"] = f"{cicon} {' '.join(parts)}".strip()

    trk = [t for t in snap.get("trackers") or [] if t.get("pct") is not None]
    if trk:
        low = min(trk, key=lambda t: t["pct"])
        lowest = low["pct"]
        if lowest <= limit:
            ticon = str(_get("tracker_icon", "") or "").strip()
            suffix = f" \u00d7{len(trk)}" if len(trk) > 1 else ""
            vals["tracker_battery"] = f"{ticon} {lowest}%{suffix}".strip()
            # which one it is - the model name the runtime reports
            vals["tracker_lowest_name"] = (low.get("name") or "").strip() \
                or None


# ------------------------------------------------------------------ fps
def _fps_values(vals):
    """{fps} {fps_raw} {frametime} {fps_source}.

    Everything stays None when FPS is off or nothing is rendering, and
    apply_template drops a None together with its separators - so a line
    like "{group_world} | {fps}" never leaves a stray pipe behind when
    you are not in a game.
    """
    if _fps is None or not _get("fps", False):
        return
    value = _fps.value()
    if value is None:
        return
    ceiling = int(_get("fps_min", 0) or 0)
    if ceiling and value >= ceiling:
        # "Only show below": above the ceiling the placeholder stays
        # empty, so the line appears exactly when the frame rate is
        # worth mentioning and gives its characters back when it is not.
        return
    icon = str(_get("fps_icon", "") or "").strip()
    suffix = " FPS" if _get("fps_unit", True) else ""
    vals["fps"] = f"{icon} {value}{suffix}".strip()
    vals["fps_raw"] = str(value)

    if _get("fps_frametime", False):
        ms = _fps.frametime()
        if ms:
            vals["frametime"] = f"{ms:.1f} ms"

    backend = _fps.backend()
    if backend:
        vals["fps_source"] = {"layer": "layer", "mangohud": "MangoHud",
                              "rtss": "RTSS"}.get(backend, backend)


# ----------------------------------------------------------------- world
def _snapshot():
    """Reads the watcher, never raising – if the log isn't there yet we
    simply report 'not in a world' instead of breaking the chatbox."""
    global _warned
    if _watcher is None or not _needs_log():
        return None
    try:
        return _watcher.snapshot()
    except Exception as e:
        if not _warned:          # log once, not every send tick
            _warned = True
            _log(f"log watcher unavailable: {e}")
        return None


def _duration(seconds, style):
    """A span of time, short enough for a chatbox line."""
    seconds = int(max(0, seconds))
    minutes, secs = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if style == "clock":
        return f"{hours}:{minutes:02d}"
    if style == "minutes":
        return f"{hours * 60 + minutes}m"
    # auto: drop the unit that would only ever read as zero
    if hours:
        return f"{hours}h {minutes:02d}m"
    if minutes:
        return f"{minutes}m"
    return f"{secs}s"


def _timer_values(vals, snap):
    """{world_time} and {vr_time}.

    Both stay empty rather than showing a zero: a line that says you
    have been here for 0m is worse than one that says nothing."""
    want_world = _get("world_time", False)
    want_vr = _get("vr_time", False)
    if not (want_world or want_vr):
        return

    style = str(_get("time_format", "auto"))
    floor = int(_get("time_min", 1) or 0) * 60
    now = time.time()

    if want_world and snap and snap.get("in_world"):
        started = float(snap.get("joined_at") or 0.0)
        if started and now - started >= floor:
            icon = str(_get("world_time_icon", "") or "").strip()
            vals["world_time"] = f"{icon} {_duration(now - started, style)}" \
                .strip()

    if not want_vr:
        return
    if str(_get("vr_time_source", "vrchat")) == "app":
        started = _app_start
    else:
        started = float((snap or {}).get("session_start") or 0.0)
    if started and now - started >= floor:
        icon = str(_get("vr_time_icon", "") or "").strip()
        vals["vr_time"] = f"{icon} {_duration(now - started, style)}".strip()


def _world_values(vals):
    snap = _snapshot()
    _timer_values(vals, snap)
    if not (snap and snap.get("in_world")):
        return
    if _get("players", True) and snap.get("player_count", 0) > 0:
        icon = str(_get("player_icon", "")).strip()
        count = str(snap["player_count"])
        vals["player_in_world"] = f"{icon} {count}".strip()
    if _get("world", True):
        world = (snap.get("world") or "").strip()
        if world:
            limit = int(_get("world_max", 24) or 24)
            if len(world) > limit:
                # hard cut, no ellipsis – chatbox characters are scarce
                world = world[:limit].rstrip()
            vals["group_world"] = world
        vals["instance_type"] = (snap.get("instance_type") or "").strip() \
            or None
    _instance_values(vals, snap)


#: {vrc_region}, "short" style
_REGION_SHORT = {"us": "US-W", "usw": "US-W", "use": "US-E", "eu": "EU",
                 "jp": "JP"}
_REGION_FLAG = {"us": "\U0001F1FA\U0001F1F8", "usw": "\U0001F1FA\U0001F1F8",
                "use": "\U0001F1FA\U0001F1F8", "eu": "\U0001F1EA\U0001F1FA",
                "jp": "\U0001F1EF\U0001F1F5"}


def _instance_values(vals, snap):
    """{vrc_region} {vrc_instance_capacity} {vrc_master} (v1.7.0)."""
    global _capacity
    code = (snap.get("region") or "").strip()
    if _get("region", False) and code:
        style = str(_get("region_style", "short"))
        if style == "flag":
            vals["vrc_region"] = _REGION_FLAG.get(code) or code.upper()
        elif style == "long":
            from .vrchatlog import REGIONS
            vals["vrc_region"] = REGIONS.get(code, code.upper())
        else:
            vals["vrc_region"] = _REGION_SHORT.get(code, code.upper())
    if _get("capacity", False):
        if _capacity is None:
            from .capacity import WorldCapacity
            _capacity = WorldCapacity(_log)
        cap = _capacity.get(snap.get("world_id") or "")
        vals["vrc_instance_capacity"] = str(cap) if cap else None
    if _get("master", False) and snap.get("is_master"):
        vals["vrc_master"] = str(_get("master_icon", "\U0001F451")).strip() \
            or None


# --------------------------------------------------------------- values
KEYS = ("fps", "fps_raw", "frametime", "fps_source",
        "player_in_world", "group_world", "instance_type",
        "vrc_region", "vrc_instance_capacity", "vrc_master",
        "world_time", "vr_time",
        "hmd_battery", "hmd_battery_raw", "hmd_battery_icon",
        "hmd_battery_bar", "controller_battery", "tracker_battery",
        "tracker_lowest_name")


#: How long one get_values() pass is reused. The host calls get_lines(),
#: get_text() AND get_values() once per chatbox frame, and the first two
#: are written in terms of the third - so a naive implementation does the
#: whole job three times for one frame: three log snapshots, three
#: battery snapshots, three FPS reads, three _sync_status() passes.
#:
#: Frames are hundreds of milliseconds apart, so a window this short only
#: ever collapses the calls that belong to the SAME frame. Nothing on
#: screen updates any later than it did before - including {realtime}
#: with seconds, which changes far slower than this.
_VALUES_TTL = 0.1
_values_cache = (0.0, None)


def _invalidate_values():
    """Drop the memoised pass, so the next frame recomputes from scratch."""
    global _values_cache
    _values_cache = (0.0, None)


def _compute_values():
    """One full pass. Everything expensive in this plugin happens here."""
    vals = {k: None for k in KEYS}
    _world_values(vals)
    _battery_values(vals)
    _fps_values(vals)
    _sync_status()      # same thread as on_tick(), so this is safe here
    return vals


def get_values():
    """Fills every placeholder this plugin owns.

    Anything switched off or unknown stays None, which apply_template
    drops together with its surrounding separators – so a template like
    "{player_in_world} | {group_world}" never leaves a stray '|' behind.

    Memoised for _VALUES_TTL – see there for why that is not a shortcut.
    """
    global _values_cache
    now = time.monotonic()
    when, cached = _values_cache
    if cached is not None and now - when < _VALUES_TTL:
        return dict(cached)     # a copy: callers may edit what they get
    vals = _compute_values()
    _values_cache = (now, vals)
    return dict(vals)


def get_text():
    """The combined line -> {world_stats}."""
    vals = get_values()
    parts = [vals["vrc_master"], vals["player_in_world"],
             vals["group_world"], vals["vrc_region"],
             vals["world_time"], vals["vr_time"], vals["hmd_battery"],
             vals["controller_battery"], vals["fps"]]
    return " | ".join(p for p in parts if p)


def get_lines():
    """Used when the custom string is switched off."""
    text = get_text()
    return [text] if text else []


# ------------------------------------------------------------- the UI
def build_widget(parent=None):
    """A small live view of what the battery backend actually sees.

    Worth its own widget because a single label row cannot show a list:
    which backend answered, which devices it found, and – the part
    people actually need – the adb serial to paste into the setting
    above when more than one device is attached."""
    from .panel import BatteryPanel
    return BatteryPanel.instance(_api, lambda: _battery, parent)
